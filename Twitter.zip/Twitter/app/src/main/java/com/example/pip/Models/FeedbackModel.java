package com.example.pip.Models;

public class FeedbackModel {
    public String uid , feedback;
    public FeedbackModel(String uid , String feedback){
        this.feedback = feedback;
        this.uid = uid;
    }
}
